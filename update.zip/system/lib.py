try:
	import os
	import urllib
	import shutil
	import requests
	import time
	import lzma 
except:
	os.system('pip install requests')
	import requests
	os.system('pip install pylzham')
	import lzma

from pathlib import Path

version = "Encryptor 3.0.0"

menu = (f"{version}\n\n\033[1;4mОсновное:\033[0m\n1) Закодировать csv : Закодирует csv (in-Decompressed)\n2) Разкодировать csv : Разкодирует зашифрованные csv (in-Compressed)\n\n\033[1;4mПрочее:\033[0m\n3) Очистить рабочие папки : Очищает папки\n4) Скачать обновление : Скачивает обновление скрипта с сервера\n---> ")

def clear():
	os.system('cls||clear')
	
def clean():
		g = input("Вы уверены?\nY - да\nN - нет\n---> ")
		
		if g == "Y":
			[f.unlink() for f in Path("in-compressed").glob("*") if f.is_file()]
			[f.unlink() for f in Path("in-decompressed").glob("*") if f.is_file()] 
			[f.unlink() for f in Path("out-compressed").glob("*") if f.is_file()] 
			[f.unlink() for f in Path("out-decompressed").glob("*") if f.is_file()] 	
			print("Готово!")
			exit()	
		elif g == "N":
			exit()
		else:
			print("Ошибка!")
	
def internet():
    from urllib import request
    try:
        urllib.request.urlopen('http://google.com')
        
        return True
    except:
        print("Нет подключения к интернету!")
        exit()
        return False
        
def decod():
	try:
		from sc_compression.compression import Decompressor, Compressor
	except ImportError:
		print("Ошибка!")
		from sc_compression.compression import Decompressor, Compressor
		
	for filename in os.listdir('in-compressed/'):
		with open(f'in-compressed/{filename}', 'rb') as fh:
			filedata = fh.read()
			fh.close()
		decompressor = Decompressor()
		decompressed = decompressor.decompress(filedata)
		with open(f'out-decompressed/{filename}', 'wb') as fh:
			fh.write(decompressed)
			fh.close()
		print(f"Файл: {filename} разкодирован!")
	
indir = './in-decompressed/'
outdir = './out-compressed/'		
              
def encod():
	for file in os.listdir(indir):
			if file.endswith('.csv'):
				os.system('python ./System/encoder_csv.py ' + indir+ file)
	
	
def update():
	from .updates import update
	
def exit():
	raise SystemExit

def create_folder():
	for i in ["in-compressed","in-decompressed","out-compressed","out-decompressed"]:
		if not os.path.exists(i):
			os.mkdir(i)