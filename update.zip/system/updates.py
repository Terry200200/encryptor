from .lib import requests, exit, time

def update(file):
    filename = file.split('/')[-1]
    print("Скачиваем архив "+ filename)
    r = requests.get(file, allow_redirects=True)
    open(filename, 'wb').write(r.content)
    print(filename +" скачан!")
    print("Распакуйте архив и запустите файл main.py")
    time.sleep(1)
    exit()


file = 'https://github.com/Terry200200/modsCreate/raw/main/update.zip'

update(file)