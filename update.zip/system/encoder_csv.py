import sys
from lib_csv import encode_file

encode_file(sys.argv[1])
