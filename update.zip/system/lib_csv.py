import os
import lzma
import lzham

def decode_file(path):
    basename = os.path.splitext(path)[0]
    decname = path[::-1]
    decname = decname[:decname.index("/")]
    csvname = decname[::-1]
    decname = "./out-decompressed/" + csvname
    decodedname = decname

    with open(path, 'rb') as f:
        data = f.read()

    tempdata = bytearray()

    for i in range(0, 8):
        tempdata.append(data[i])

    for i in range(0, 4):
        tempdata.append(0)

    for i in range(8, len(data)):
        tempdata.append(data[i])

    try:
        with open(decodedname, 'wb') as f:
            decompressor = lzma.LZMADecompressor()
            unpack_data = decompressor.decompress(tempdata)
            f.write(unpack_data)
    except:
        print("Неверный файл: " + csvname)

def len_2_bytes(datalen, max_len=4):
    data = []
    while datalen > 0:
        item = datalen % 256
        datalen = int(datalen / 256)
        data.append(item)
    while len(data) < max_len:
        data.append(0)
    return data

def encode_file(path, max_len=4):
    basename = os.path.splitext(path)[0]
    encname = path[::-1]
    encname = encname[:encname.index("/")]
    csvname = encname[::-1]
    encname = "./out-compressed/" + csvname
    encodedname = encname

    print("Файл: " + csvname + " закодирован!")

    with open(path, 'rb') as f:
        data = f.read()

    filters = [
        {
            "id": lzma.FILTER_LZMA1,
            "dict_size": 256 * 1024,
            "lc": 2,
            "lp": 1,
            "pb": 4,
            "mode": lzma.MODE_NORMAL
        },
    ]

    pack_data = lzma.compress(data, format=lzma.FORMAT_ALONE, filters=filters)

    lzmadata = bytearray()

    for i in range(0, 5):
        lzmadata.append(pack_data[i])

    data_size = len_2_bytes(len(data), max_len)
    for size in data_size:
        lzmadata.append(size)

    for i in range(13, len(pack_data)):
        lzmadata.append(pack_data[i])


    with open(encodedname, 'wb') as f:
        f.write(lzmadata)

def restore_file(path):
    with open(path, 'rb') as f:
        data = f.read()

    tempdata = bytearray()

    for i in range(0, 8):
        tempdata.append(data[i])

    for i in range(0, 4):
        tempdata.append(0)

    for i in range(8, len(data)):
        tempdata.append(data[i])

    with open('real.lzma', 'wb') as f:
        f.write(tempdata)
