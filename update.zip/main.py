from system.lib import *

clear()
create_folder()
		
def main():
	a = input(menu)
	if a == "1":
		clear()
		encod()
		exit()
	elif a == "2":
		clear()
		decod()
		exit()
	elif a == "3":
		clear()
		clean()
		exit()
	elif a == "4":
		clear()
		internet()
		update()
	else:
		clear()
		print("Ошибка!")	

	main()
main()
